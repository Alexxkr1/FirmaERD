﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class LoanFromFirm
    {
        [Key]
        public Guid Id { get; set; }
        //public string Worker_Id { get; set; }
        public string Loaned_Thing { get; set; }
        public int Quantity { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Comment { get; set; }



    }
}