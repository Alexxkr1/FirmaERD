﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class Vacations
    {
        [Key]
        public Guid Id { get; set; }
        //public string Worker_Id { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Vacation_Type { get; set; }
   
        public IEnumerable<IllnesSheet> Childrens { get; set; } = new List<IllnesSheet>();
        public string Comment { get; set; }



    }
}