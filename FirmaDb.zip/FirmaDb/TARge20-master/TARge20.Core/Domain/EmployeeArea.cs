﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class EmployeeArea
    {
        [Key]
        public Guid Id { get; set; }
        //public string Worker_Id { get; set; }
        public IEnumerable<EmployeeArea> EmployeeAreas { get; set; } = new List<EmployeeArea>();
        public DateTime Start_Date { get; set; }
        public DateTime End_Date { get; set; }
        public string Comment { get; set; }



    }
}
