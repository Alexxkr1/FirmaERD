﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class HealthCheck
    {
        [Key]
        public Guid Id { get; set; }
        public string Hint { get; set; }
        public string EmployeeHealth { get; set; }
        public DateTime Date_Hint { get; set; }
        public string Comment { get; set; }
    }
}
