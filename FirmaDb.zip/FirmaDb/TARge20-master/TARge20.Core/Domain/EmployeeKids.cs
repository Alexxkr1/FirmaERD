﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class EmployeeKids
    {
        [Key]
        public Guid Id { get; set; }
        //public string Worker_Id { get; set; }
        public int Countity { get; set; }
        public int ID_Code { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Comment { get; set; }
    }
}
