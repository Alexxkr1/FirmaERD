﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class Branch
    {
        [Key]
        public Guid Id { get; set; }
        public int Registery_Number { get; set; }
        public int Code { get; set; }
        public string Name { get; set; }
        public int Arriving_frequency { get; set; }
        public string Comment { get; set; }
    }
}
