﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class Area
    {
        [Key]
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DateTime Founding_Date { get; set; }
        public DateTime Closing_Date { get; set; }
        public string Comment { get; set; }
    }
}
