﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace TARge20.Core.Domain
{
    public class IllnesSheet
    {
        [Key]
        public Guid Id { get; set; }
        //public string Worker_Id { get; set; }
        public IEnumerable<HealthCheck> HealthCheck { get; set; } = new List<HealthCheck>();
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Vacation_Type { get; set; }
        public string Illnes { get; set; }
        public string Comment { get; set; }



    }
}