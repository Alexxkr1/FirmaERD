﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TARge20.Data.Migrations
{
    public partial class FirmaERD : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Area",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Founding_Date = table.Column<DateTime>(nullable: false),
                    Closing_Date = table.Column<DateTime>(nullable: false),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Area", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Branches",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Registery_Number = table.Column<int>(nullable: false),
                    Code = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Arriving_frequency = table.Column<int>(nullable: false),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Branches", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    First_Name = table.Column<string>(nullable: true),
                    Last_Name = table.Column<string>(nullable: true),
                    ID_Code = table.Column<int>(nullable: false),
                    Contact_Address = table.Column<string>(nullable: true),
                    Contact_Telefon = table.Column<string>(nullable: true),
                    Contact_email = table.Column<string>(nullable: true),
                    Work_Start = table.Column<DateTime>(nullable: false),
                    Work_Until = table.Column<DateTime>(nullable: false),
                    Age = table.Column<int>(nullable: false),
                    Sex = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Firm",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    RegisterNr = table.Column<int>(nullable: false),
                    Code = table.Column<int>(nullable: false),
                    ArrivingFrequency = table.Column<int>(nullable: false),
                    Name = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Firm", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "VacationStatuses",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VacationStatuses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AdministrationAccesses",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdministrationAccesses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AdministrationAccesses_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeAccesses",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Permissions = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeAccesses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmployeeAccesses_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeAreas",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Start_Date = table.Column<DateTime>(nullable: false),
                    End_Date = table.Column<DateTime>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeAreaId = table.Column<Guid>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeAreas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmployeeAreas_EmployeeAreas_EmployeeAreaId",
                        column: x => x.EmployeeAreaId,
                        principalTable: "EmployeeAreas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_EmployeeAreas_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeKids",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Countity = table.Column<int>(nullable: false),
                    ID_Code = table.Column<int>(nullable: false),
                    First_Name = table.Column<string>(nullable: true),
                    Last_Name = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeKids", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmployeeKids_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeOccupations",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Salary = table.Column<int>(nullable: false),
                    Occupation = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeOccupations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmployeeOccupations_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Hints",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Health_Problems = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hints", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Hints_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "LoanFromFirms",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Loaned_Thing = table.Column<string>(nullable: true),
                    Quantity = table.Column<int>(nullable: false),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoanFromFirms", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LoanFromFirms_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Requests",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Request = table.Column<string>(nullable: true),
                    Request_Date = table.Column<DateTime>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Requests", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Requests_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Vacations",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false),
                    Vacation_Type = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vacations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Vacations_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "IllnesSheets",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false),
                    Vacation_Type = table.Column<string>(nullable: true),
                    Illnes = table.Column<string>(nullable: true),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true),
                    VacationsId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IllnesSheets", x => x.Id);
                    table.ForeignKey(
                        name: "FK_IllnesSheets_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_IllnesSheets_Vacations_VacationsId",
                        column: x => x.VacationsId,
                        principalTable: "Vacations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "HealthChecks",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Hint = table.Column<string>(nullable: true),
                    EmployeeHealth = table.Column<string>(nullable: true),
                    Date_Hint = table.Column<DateTime>(nullable: false),
                    Comment = table.Column<string>(nullable: true),
                    EmployeeId = table.Column<Guid>(nullable: true),
                    IllnesSheetId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HealthChecks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HealthChecks_Employee_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employee",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_HealthChecks_IllnesSheets_IllnesSheetId",
                        column: x => x.IllnesSheetId,
                        principalTable: "IllnesSheets",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AdministrationAccesses_EmployeeId",
                table: "AdministrationAccesses",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeAccesses_EmployeeId",
                table: "EmployeeAccesses",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeAreas_EmployeeAreaId",
                table: "EmployeeAreas",
                column: "EmployeeAreaId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeAreas_EmployeeId",
                table: "EmployeeAreas",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeKids_EmployeeId",
                table: "EmployeeKids",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeOccupations_EmployeeId",
                table: "EmployeeOccupations",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_HealthChecks_EmployeeId",
                table: "HealthChecks",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_HealthChecks_IllnesSheetId",
                table: "HealthChecks",
                column: "IllnesSheetId");

            migrationBuilder.CreateIndex(
                name: "IX_Hints_EmployeeId",
                table: "Hints",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_IllnesSheets_EmployeeId",
                table: "IllnesSheets",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_IllnesSheets_VacationsId",
                table: "IllnesSheets",
                column: "VacationsId");

            migrationBuilder.CreateIndex(
                name: "IX_LoanFromFirms_EmployeeId",
                table: "LoanFromFirms",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Requests_EmployeeId",
                table: "Requests",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Vacations_EmployeeId",
                table: "Vacations",
                column: "EmployeeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AdministrationAccesses");

            migrationBuilder.DropTable(
                name: "Area");

            migrationBuilder.DropTable(
                name: "Branches");

            migrationBuilder.DropTable(
                name: "EmployeeAccesses");

            migrationBuilder.DropTable(
                name: "EmployeeAreas");

            migrationBuilder.DropTable(
                name: "EmployeeKids");

            migrationBuilder.DropTable(
                name: "EmployeeOccupations");

            migrationBuilder.DropTable(
                name: "Firm");

            migrationBuilder.DropTable(
                name: "HealthChecks");

            migrationBuilder.DropTable(
                name: "Hints");

            migrationBuilder.DropTable(
                name: "LoanFromFirms");

            migrationBuilder.DropTable(
                name: "Requests");

            migrationBuilder.DropTable(
                name: "VacationStatuses");

            migrationBuilder.DropTable(
                name: "IllnesSheets");

            migrationBuilder.DropTable(
                name: "Vacations");

            migrationBuilder.DropTable(
                name: "Employee");
        }
    }
}
